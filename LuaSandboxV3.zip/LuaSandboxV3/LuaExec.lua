print("Welcome to the sandbox, to get you started i will show you all of the functions this sandbox has to offer...")
for i,v in pairs(_G)do
	print(i)
end
print("for documentation, visit https://raw.githubusercontent.com/LOOF-sys/Lua-Sandbox/main/README.md")
local link = "https://raw.githubusercontent.com/LOOF-sys/Lua-Sandbox/main/README.md"